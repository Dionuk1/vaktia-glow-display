// src/lib/albania-times.ts
var ALBANIA_COUNCILS = [
  "Tirane",
  "Shkoder",
  "Lezhe",
  "Durres",
  "Elbasan",
  "Korce",
  "Vlore",
  "Fier",
  "Gjirokaster",
  "Kukes",
  "Berat",
  "Diber"
];
var ALBANIA_COUNCIL_LABELS = {
  Tirane: "Tiranë",
  Shkoder: "Shkodër",
  Lezhe: "Lezhë",
  Durres: "Durrës",
  Elbasan: "Elbasan",
  Korce: "Korçë",
  Vlore: "Vlorë",
  Fier: "Fier",
  Gjirokaster: "Gjirokastër",
  Kukes: "Kukës",
  Berat: "Berat",
  Diber: "Dibër"
};
var ALBANIA_CITIES = [
  "Tirane",
  "Shkoder",
  "Velipoje",
  "Lezhe",
  "Shengjin",
  "Durres",
  "Elbasan",
  "Korce",
  "Vlore",
  "Fier",
  "Gjirokaster",
  "Kukes",
  "Berat",
  "Diber"
];
var ALBANIA_CITY_LABELS = {
  ...ALBANIA_COUNCIL_LABELS,
  Velipoje: "Velipojë",
  Shengjin: "Shëngjin"
};
var CITY_TO_COUNCIL = {
  Tirane: "Tirane",
  Shkoder: "Shkoder",
  Velipoje: "Shkoder",
  Lezhe: "Lezhe",
  Shengjin: "Lezhe",
  Durres: "Durres",
  Elbasan: "Elbasan",
  Korce: "Korce",
  Vlore: "Vlore",
  Fier: "Fier",
  Gjirokaster: "Gjirokaster",
  Kukes: "Kukes",
  Berat: "Berat",
  Diber: "Diber"
};
function getCouncilForCity(city) {
  return CITY_TO_COUNCIL[city] ?? "Tirane";
}
function getCouncilLabelForCity(city) {
  return ALBANIA_COUNCIL_LABELS[getCouncilForCity(city)];
}
var ALBANIA_CITY_COORDS = {
  Tirane: { lat: 41.3275, lon: 19.8187 },
  Shkoder: { lat: 42.0693, lon: 19.5033 },
  Velipoje: { lat: 41.8697, lon: 19.4181 },
  Lezhe: { lat: 41.7836, lon: 19.6436 },
  Shengjin: { lat: 41.8153, lon: 19.5936 },
  Durres: { lat: 41.3231, lon: 19.4414 },
  Elbasan: { lat: 41.1125, lon: 20.0822 },
  Korce: { lat: 40.6186, lon: 20.7808 },
  Vlore: { lat: 40.4667, lon: 19.4897 },
  Fier: { lat: 40.7239, lon: 19.5567 },
  Gjirokaster: { lat: 40.0758, lon: 20.1389 },
  Kukes: { lat: 42.0769, lon: 20.4219 },
  Berat: { lat: 40.7058, lon: 19.9522 },
  Diber: { lat: 41.6853, lon: 20.4292 }
};
var COUNCIL_COORDS = ALBANIA_COUNCILS.reduce((acc, c) => {
  acc[c] = ALBANIA_CITY_COORDS[c];
  return acc;
}, {});
var FAJR_ANGLE = 18;
var ISHA_ANGLE = 17;
var SABAH_AFTER_IMSAK = 30;
var MAGHRIB_DELAY = 3;
var ASR_SHADOW_FACTOR = 1;
var DEG = Math.PI / 180;
var sin = (d) => Math.sin(d * DEG);
var cos = (d) => Math.cos(d * DEG);
var tan = (d) => Math.tan(d * DEG);
var asin = (x) => Math.asin(x) / DEG;
var acos = (x) => Math.acos(x) / DEG;
var atan2d = (y, x) => Math.atan2(y, x) / DEG;
function julianDay(y, m, d) {
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  const a = Math.floor(y / 100);
  const b = 2 - a + Math.floor(a / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
}
function sunPosition(jd) {
  const d = jd - 2451545;
  const g = (357.529 + 0.98560028 * d) % 360;
  const q = (280.459 + 0.98564736 * d) % 360;
  const L = (q + 1.915 * sin(g) + 0.02 * sin(2 * g)) % 360;
  const e = 23.439 - 0.00000036 * d;
  const RA = atan2d(cos(e) * sin(L), cos(L)) / 15;
  const decl = asin(sin(e) * sin(L));
  const eqt = q / 15 - (RA + 24) % 24;
  return { decl, eqt: eqt * 60 };
}
function hourAngle(altitude, lat, decl) {
  const x = (sin(altitude) - sin(lat) * sin(decl)) / (cos(lat) * cos(decl));
  if (x > 1 || x < -1)
    return null;
  return acos(x) / 15;
}
function albaniaUtcOffset(date) {
  const y = date.getFullYear();
  const lastSunday = (month) => {
    const d = new Date(Date.UTC(y, month + 1, 0));
    d.setUTCDate(d.getUTCDate() - d.getUTCDay());
    return d;
  };
  const dstStart = lastSunday(2);
  dstStart.setUTCHours(1, 0, 0, 0);
  const dstEnd = lastSunday(9);
  dstEnd.setUTCHours(1, 0, 0, 0);
  const utcNoon = Date.UTC(y, date.getMonth(), date.getDate(), 12);
  return utcNoon >= dstStart.getTime() && utcNoon < dstEnd.getTime() ? 2 : 1;
}
function fmtHours(h) {
  let mins = Math.round(h * 60);
  mins = (mins % 1440 + 1440) % 1440;
  const hh = Math.floor(mins / 60);
  const mm = mins % 60;
  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}
function computeCouncilTimes(date, council) {
  const { lat, lon } = COUNCIL_COORDS[council] ?? COUNCIL_COORDS.Tirane;
  const tz = albaniaUtcOffset(date);
  const jd = julianDay(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lon / (15 * 24);
  const { decl, eqt } = sunPosition(jd);
  const noon = 12 - eqt / 60 - lon / 15 + tz;
  const dhuhr = noon + 3 / 60;
  const sunriseHA = hourAngle(-0.833, lat, decl);
  const fajrHA = hourAngle(-FAJR_ANGLE, lat, decl);
  const ishaHA = hourAngle(-ISHA_ANGLE, lat, decl);
  const asrAltitude = atan2d(1, ASR_SHADOW_FACTOR + tan(Math.abs(lat - decl)));
  const asrHA = hourAngle(asrAltitude, lat, decl);
  const sunrise = sunriseHA !== null ? noon - sunriseHA : noon - 6;
  const sunset = sunriseHA !== null ? noon + sunriseHA : noon + 6;
  const imsak = fajrHA !== null ? noon - fajrHA : sunrise - 1.5;
  const asr = asrHA !== null ? noon + asrHA : noon + 4;
  const maghrib = sunset + MAGHRIB_DELAY / 60;
  const isha = ishaHA !== null ? noon + ishaHA : maghrib + 1.5;
  return {
    imsaku: fmtHours(imsak),
    sabahu: fmtHours(imsak + SABAH_AFTER_IMSAK / 60),
    lindja: fmtHours(sunrise),
    dreka: fmtHours(dhuhr),
    ikindia: fmtHours(asr),
    akshami: fmtHours(maghrib),
    jacia: fmtHours(Math.max(isha, maghrib + 70 / 60))
  };
}
function getAlbanianTimesForDate(date, city) {
  return computeCouncilTimes(date, getCouncilForCity(city));
}
function getAlbanianMonthTimes(year, month, city) {
  const days = new Date(year, month + 1, 0).getDate();
  const out = [];
  for (let d = 1;d <= days; d++) {
    const date = new Date(year, month, d);
    out.push({ date, times: getAlbanianTimesForDate(date, city) });
  }
  return out;
}
function nearestAlbanianCity(lat, lon) {
  let best = "Tirane";
  let bestD = Infinity;
  for (const c of ALBANIA_CITIES) {
    const { lat: a, lon: b } = ALBANIA_CITY_COORDS[c];
    const dx = (b - lon) * Math.cos((a + lat) / 2 * (Math.PI / 180));
    const dy = a - lat;
    const d = dx * dx + dy * dy;
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best;
}
function isInsideAlbania(lat, lon) {
  return lat >= 39.6 && lat <= 42.7 && lon >= 19 && lon <= 21.06;
}
var ALBANIA_COUNCIL_GENITIVE = {
  Tirane: "Tiranës",
  Shkoder: "Shkodrës",
  Lezhe: "Lezhës",
  Durres: "Durrësit",
  Elbasan: "Elbasanit",
  Korce: "Korçës",
  Vlore: "Vlorës",
  Fier: "Fierit",
  Gjirokaster: "Gjirokastrës",
  Kukes: "Kukësit",
  Berat: "Beratit",
  Diber: "Dibrës"
};
function getCouncilGenitiveForCity(city) {
  return ALBANIA_COUNCIL_GENITIVE[getCouncilForCity(city)];
}
export {
  ALBANIA_CITIES,
  ALBANIA_CITY_COORDS,
  ALBANIA_CITY_LABELS,
  ALBANIA_COUNCILS,
  ALBANIA_COUNCIL_GENITIVE,
  ALBANIA_COUNCIL_LABELS,
  CITY_TO_COUNCIL,
  COUNCIL_COORDS,
  computeCouncilTimes,
  getAlbanianMonthTimes,
  getAlbanianTimesForDate,
  getCouncilForCity,
  getCouncilGenitiveForCity,
  getCouncilLabelForCity,
  isInsideAlbania,
  nearestAlbanianCity
};
